//: Playground - noun: a place where people can play

import UIKit

enum StatusCode :Int {
    case success = 200
    case unauthorized = 401
    case forbidden = 403
    case notFound = 404
}
func prettyPrint(x:StatusCode) -> String{
    switch x {
    case StatusCode.success:
        return(String(x.rawValue)+": Success")
    case StatusCode.unauthorized:
        return(String(x.rawValue)+": Unauthorized")
    case StatusCode.forbidden:
        return(String(x.rawValue)+": Forbidden")
    case StatusCode.notFound:
        return(String(x.rawValue)+": Not Found")
    }
}

